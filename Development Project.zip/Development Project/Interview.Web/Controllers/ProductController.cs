﻿using Interview.Web.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Interview.Web.Controllers
{
    [Route("api/v1/products")]
    public class ProductController : Controller
    {
        readonly IProductService _productService;

        ProductController(IProductService productService)
        {
            _productService = productService;
        }
        // NOTE: Sample Action
        [HttpGet]
        public Task<IActionResult> GetAllProducts()
        {
            var result = _productService.getProducts();
            return Task.FromResult((IActionResult)Ok(result));
        }

        [HttpGet]
        public Task<IActionResult> SearchProducts(string name)
        {
            var result = _productService.searchProducts(name);
            return Task.FromResult((IActionResult)Ok(result));
        }
    }
}
