﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Interview.Web.Services
{
    interface IProductService
    {
        Task<object> getProducts();
        Task<object> searchProducts(string name);
    }
}
