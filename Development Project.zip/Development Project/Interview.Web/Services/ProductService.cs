﻿using Dapper;
using Sparcpoint.SqlServer.Abstractions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace Interview.Web.Services
{
    public class ProductService: IProductService
    {
        readonly ISqlExecutor _sqlExecutor;
        public ProductService(ISqlExecutor sqlExecutor)
        {
            _sqlExecutor = sqlExecutor;
        }

        public async Task<object> getProducts()
        {

            return await _sqlExecutor.ExecuteAsync(async c =>
            {
                var products = await c.QueryAsync<object>(sql: "SELECT * FROM PRODUCTS", commandType: CommandType.Text);
                return products;
            });

        }

        public async Task<object> searchProducts(string name)
        {
            return await _sqlExecutor.ExecuteAsync(async c =>
            {
                var p = new DynamicParameters();
                var products = await c.QueryAsync<object>(sql: "SELECT * FROM PRODUCTS P INNER JOIN CATEGORIES C ON P.InstanceId = C.InstanceId WHERE NAME LIKE %" + name + "%", commandType: CommandType.Text);
                return products.FirstOrDefault();
            });

        }

    }
}
