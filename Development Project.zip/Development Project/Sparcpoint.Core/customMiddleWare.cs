﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Sparcpoint
{

    public static class AuthorizationMiddlewareExtensions
    {
        public static IApplicationBuilder AuthMiddleware(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<CustomMiddleWare>();
        }
    }
    public class CustomMiddleWare
    {
        public CustomMiddleWare()
        {
        }

        public async Task InvokeAsync(HttpContext context)
        {
            var token = new PBKDF2PasswordHasher().CreateNewHashSet("test");
            //if (!string.IsNullOrEmpty(token))
            //{

            //}


        }
    }
}
