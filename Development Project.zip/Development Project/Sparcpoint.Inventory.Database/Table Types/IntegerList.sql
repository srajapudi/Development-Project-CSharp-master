﻿CREATE TYPE [dbo].[IntegerList] AS TABLE
(
	[Value] INT NOT NULL
)
