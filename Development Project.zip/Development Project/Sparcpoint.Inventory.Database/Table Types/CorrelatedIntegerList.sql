﻿CREATE TYPE [dbo].[CorrelatedIntegerList] AS TABLE
(
	[Index] INT NOT NULL,
	[Value] INT NOT NULL
)
